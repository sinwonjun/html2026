#include "maze.h"
 
int dr[4] = {-1, 1, 0, 0};
int dc[4] = {0, 0, -1, 1};
 
void initMaze(char maze[HEIGHT][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++)
        for (int j = 0; j < WIDTH; j++)
            maze[i][j] = WALL;
    for (int r = 0; r < ROWS; r++)
        for (int c = 0; c < COLS; c++)
            maze[2*r+1][2*c+1] = PATH;
}
 
void printMaze(char maze[HEIGHT][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++)
            printf("%c ", maze[i][j]);
        printf("\n");
    }
}
